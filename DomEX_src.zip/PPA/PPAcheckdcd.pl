#!/usr/bin/perl 
use strict;
use warnings;
use Math::Trig;
########### setup  the environment and Working DIRectory ###
$ENV{'PATH'} =
"/usr/local/bin:/bin:/usr/bin:/usr/X11R6/bin:/usr/pgi/linux86/bin:/usr/pbs/bin";
$ENV{'LD_LIBRARY_PATH'} = "/usr/local/lib:/usr/lib:/lib";

my $USER =`whoami`;
   chomp($USER);
my $DSAM_DIR = "/home/$USER/DSAM_WEB";
my $DATA_DIR  = "$DSAM_DIR/output";
my $BLAST_DIR = "$DSAM_DIR/blast/bin";
my $NRDB_DIR  = "$DSAM_DIR/nr/nr";
my $zalignbin = "$DSAM_DIR/bin/zalign";
my  $Pexecdir  = "$DSAM_DIR/bin/psipred24/bin";    #psipred excutable file
my  $Pdatadir  = "$DSAM_DIR/bin/psipred24/data";   #psipred data file
my  $PSSpreddir ="$DSAM_DIR/bin/PSSpred";           #where PSSpred files are

my $WORK_DIR  = "/tmp/$USER/test";

my %ts;
my @AA;
&init();

################ working directory ########################

    my $templateId = $ARGV[1];
    my $queryId    = $ARGV[0];
    my $queryShiftId    = $ARGV[2];
    $WORK_DIR .= "/$queryId/$queryShiftId";
    $DATA_DIR .= "/$queryId/$queryShiftId"; 
    
    
   `/bin/mkdir -p $WORK_DIR`;
    chdir "$WORK_DIR";
    `/bin/rm -f $WORK_DIR/*`;
   
    `cp "$DSAM_DIR/lib2/seq_90/$templateId.fasta" "."`;
    `cp "$DATA_DIR/$queryShiftId.fasta" "."`;
   
    &genSeq($templateId);
    &genSeq($queryShiftId);
    &genSec($templateId);
    &genSec($queryShiftId);
    &genQueryProfile($queryShiftId);
    &PPA( $queryShiftId, $templateId );
    `/bin/rm -rf $WORK_DIR`;   

################ make fasta sequence file #################
sub genSeq() {
    my ($query)  = @_;
    my @seqtxts  = `cat "$query.fasta"`;
    my $sequence = "";
    foreach my $seqtxt (@seqtxts) {
        goto pos6 if ( $seqtxt =~ /\>/ );
        $seqtxt =~ s/\s//mg;
        $seqtxt =~ s/\n//mg;
        $seqtxt   = uc($seqtxt);
        $sequence = $sequence . $seqtxt;
      pos6:;
    }
    my $Lch = length $sequence;
    open( WR, ">$query.seq" );
    printf WR ">$query\n";
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        my $a = substr( $sequence, $i - 1, 1 );
        foreach my $A (@AA) {
            goto pos2a if ( $a eq $A );
        }
        $a = "G";
      pos2a:;
        printf WR "$a";
        if ( $i == int( $i / 60 ) * 60 ) {
            printf WR "\n";
        }
    }
    printf WR "\n";
    close(WR);
    `cp $query.fasta $DATA_DIR/$query.fasta`;
    `cp $query.seq $DATA_DIR/$query.seq`;
}

sub genSec() {
    my ($domainId) = @_;

########### run psi-blast #######################
    if ( not -s "$domainId.chk" ) {
        print("blasting.....\n");
`$BLAST_DIR/blastpgp  -b 1000 -j 3 -h 0.001 -d "$NRDB_DIR" -i "$domainId.fasta" -C "$domainId.chk" -Q "$domainId.pssm" > "$domainId.out"`;
    }

    my $ws = `pwd`;
    print("after blast:$ws\n");
########### make .mtx ##############
    open( WR, ">$WORK_DIR/$domainId.pn" );
    printf WR "$domainId.chk\n";
    close(WR);

    open( WR, ">$WORK_DIR/$domainId.sn" );
    printf WR "$domainId.fasta\n";
    close(WR);
    `$BLAST_DIR/makemat -P $domainId`;

    `cp "$domainId.chk" "$DATA_DIR/psitmp.chk"`;
    `cp "$domainId.out" "blast.out"`;
    `cp "$domainId.pssm" "pssm.txt"`;
    `cp "$domainId.mtx" "mtx"`;
######### psipred ################

    &runPsipred($domainId);
######### PSSpred ################
    &runPSSpred($domainId);

######### combine PSIpred and PSSpred into 'seq.dat'---------->
    &combine_SS($domainId);

################# translate sec format######################

    open( RD, "$domainId.dat" );
    my $sec = "";
    my $num = 0;
    while ( my $line = <RD> ) {
        $line =~ /(\S+)\s+\S+\s+(\S+)\s+\S+/;
        $sec .= "$2";
        $num++;
    }
    close(RD);

    open( WR, ">$domainId.sec" );
    printf WR ">$domainId   $num\n";
    my $newsec = "";
    while ( length($sec) > 70 ) {
        $newsec .= substr( $sec, 0, 70 ) . "\n";
        $sec = substr( $sec, 70 );
    }

    $newsec .= "$sec\n";

    printf WR "$newsec";
    close(WR);

}

sub genQueryProfile() {
    my ($query) = @_;
    my ( %seqQ, %log );
################ make fasta sequence file #################
    my @seqtxts  = `cat "$WORK_DIR/$query.fasta"`;
    my $sequence = "";
    foreach my $seqtxt (@seqtxts) {
        goto pos6 if ( $seqtxt =~ /\>/ );
        $seqtxt =~ s/\s//mg;
        $seqtxt =~ s/\n//mg;
        $seqtxt   = uc($seqtxt);
        $sequence = $sequence . $seqtxt;
      pos6:;
    }
    my $Lch = length $sequence;
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        my $a = substr( $sequence, $i - 1, 1 );
        foreach my $A (@AA) {
            goto pos2a if ( $a eq $A );
        }
        $a = "G";
      pos2a:;
        $seqQ{$i} = $a;    #only for check
        $log{ $i, $seqQ{$i} }++;
    }

########### extract 'pre.prf' ###################
#### record multiple sequence alignment $am{i_seq,i_pos} -------->
    my $ROUND = 0;
    my %am;
    my $it = 0;
    my %nA;
    open( BLAST, "$query.out" );
    while ( my $line = <BLAST> ) {
        if ( $line =~ /Results from round\s+(\d+)/ ) {
            $ROUND = $1;
        }
    }
    seek( BLAST, 0, 0 );
    while ( my $line = <BLAST> ) {
        if ( $line =~ /round\s+$ROUND/ ) {
            while ( $line = <BLAST> ) {
                if ( $line =~ /Expect =\s*(\S+),/ ) {
                    my $ev = $1;
                    if ( $ev =~ /e/ ) {
                        $ev = "1$ev";
                        $ev = sprintf( "%0.9f", $ev );
                    }
                    <BLAST> =~ /Identities =\s*\S+\s+\((\S+)\%/;
                    <BLAST>;
                    my $id = $1;
                    if ( $ev < 0.001 && $id < 98 ) {
                        $it++;    #number of aligned sequences
                        while ( $line = <BLAST> ) {
                            if ( $line =~ /Query\:\s*(\d+)\s+(\S+)\s+(\S+)/ ) {
                                my $i1   = $1;
                                my $seq1 = $2;
                                <BLAST>;
                                <BLAST> =~ /Sbjct\:\s*(\S+)\s+(\S+)\s+(\S+)/;
                                my $seq2 = $2;
                                <BLAST>;
                                ###
                                my $L  = length $seq1;
                                my $m1 = $i1 - 1;
                                for ( my $i = 1 ; $i <= $L ; $i++ ) {
                                    my $q1 = substr( $seq1, $i - 1, 1 );
                                    my $q2 = substr( $seq2, $i - 1, 1 );
                                    $m1++ if ( $q1 ne '-' );
                                    if ( $q1 ne '-' && $q2 ne '-' ) {
                                        $am{ $it, $m1 } = $q2;

                                        #$log{$m1,$q2}++;
                                    }
                                }
                                ###
                            }
                            else {
                                goto pos1;
                            }
                        }
                    }
                  pos1:;
                }
            }
        }
    }
    close(BLAST);
######## include query sequence ---------->
    $it++;
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        $am{ $it, $i } = $seqQ{$i};
    }
####### Henikoff weight $wei{i_seq} ----------->
##### nA{A,i_pos}: number of times A appear at the position:
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        for ( my $j = 1 ; $j <= $it ; $j++ ) {
           $am{$j,$i}="" if(not $am{$j,$i});
            $nA{ $am{ $j, $i }, $i }++;
        }
    }
##### henikoff weight w(i)=sum of 1/rs:
    my $w_all;
    my %w;

    for ( my $i = 1 ; $i <= $it ; $i++ ) {
        for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
            ####### r: number of different residues in j'th position:
            my $r = 0;
            foreach my $A (@AA) {
                
                $r++ if ( $nA{$A,$j} and $nA{ $A, $j } > 0 );
            }
            my $A  = $am{ $i, $j };
            my $s2 = $nA{ $A, $j };
            my $w1 = 1.0 / ( $r * $s2 );
            $w{$i} += $w1;
        }
        $w_all += $w{$i};
    }
#### normalization of w(i):
    for ( my $i = 1 ; $i <= $it ; $i++ ) {
        $w{$i} /= $w_all;
    }

    #^^^^^ Henikoff weight finished ^^^^^^^^^^^^^^^^^

########### weighted FREQuence #################
    undef %log;
    for ( my $i = 1 ; $i <= $it ; $i++ ) {
        for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
            my $A = $am{ $i, $j };
            $log{ $j, $A } += $w{$i};
        }
    }

    #^^^^^^^^^ Henikoff FREQuence finished ^^^^^^^^^^^^^

    open( FREQ, ">$query.prf" );
    printf FREQ "$Lch\n";
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        printf FREQ "%3d $seqQ{$i} %3d", $i, $i;
        my $norm = 0;
        foreach my $A (@AA) {
            $log{$i,$A}=0 if(not $log{$i,$A});
            $norm += $log{ $i, $A };
        }
        foreach my $A (@AA) {
            printf FREQ "%10.7f", $log{ $i, $A } / $norm;
        }
        printf FREQ "\n";
    }
    close(FREQ);
}

########### run zalign #############
sub PPA() {
    my ( $query, $template ) = @_;
    my $query1    = $query;
    my $template1 = $template;

    $query1 = substr( $query1, 0, 9 ) if ( length($query) > 9 );

    if ( length($template) > 9 ) {
        $template1 = substr( $template1, 0, 9 );
        `cp $template.mtx $template1.mtx`;
        `cp $template.seq $template1.seq`;
        `cp $template.sec $template1.sec`;
    }else{
     $template1=$template;
   }
    open( IN, ">in.dd" );
    printf IN "$query.dat\n";    #secendary structure
    printf IN "$query.seq\n";
    printf IN "$query.prf\n";
    printf IN "\'$template1.seq\'\n";
    printf IN "\'$template1.sec\'\n";
    printf IN "\'\'\n";
    close(IN);

    `cp $zalignbin/zal2 ./zalign`;
    printf "running zalign .....\n";
    `./zalign`;
    `cp rst.dat $DATA_DIR/$query.rst`;
    my @str = `cat rst.dat`;
    print("$str[0]\n");

################# endding procedure ######################
    `rm -fr $WORK_DIR`;

}

sub init() {

    %ts = (
        'GLY' => 'G',
        'ALA' => 'A',
        'VAL' => 'V',
        'LEU' => 'L',
        'ILE' => 'I',
        'SER' => 'S',
        'THR' => 'T',
        'CYS' => 'C',
        'MET' => 'M',
        'PRO' => 'P',
        'ASP' => 'D',
        'ASN' => 'N',
        'GLU' => 'E',
        'GLN' => 'Q',
        'LYS' => 'K',
        'ARG' => 'R',
        'HIS' => 'H',
        'PHE' => 'F',
        'TYR' => 'Y',
        'TRP' => 'W',

        'ASX' => 'B',
        'GLX' => 'Z',
        'UNK' => 'X',

        'G' => 'GLY',
        'A' => 'ALA',
        'V' => 'VAL',
        'L' => 'LEU',
        'I' => 'ILE',
        'S' => 'SER',
        'T' => 'THR',
        'C' => 'CYS',
        'M' => 'MET',
        'P' => 'PRO',
        'D' => 'ASP',
        'N' => 'ASN',
        'E' => 'GLU',
        'Q' => 'GLN',
        'K' => 'LYS',
        'R' => 'ARG',
        'H' => 'HIS',
        'F' => 'PHE',
        'Y' => 'TYR',
        'W' => 'TRP',

        'a' => 'CYS',
        'b' => 'CYS',
        'c' => 'CYS',
        'd' => 'CYS',
        'e' => 'CYS',
        'f' => 'CYS',
        'g' => 'CYS',
        'h' => 'CYS',
        'i' => 'CYS',
        'j' => 'CYS',
        'k' => 'CYS',
        'l' => 'CYS',
        'm' => 'CYS',
        'n' => 'CYS',
        'o' => 'CYS',
        'p' => 'CYS',
        'q' => 'CYS',
        'r' => 'CYS',
        's' => 'CYS',
        't' => 'CYS',
        'u' => 'CYS',
        'v' => 'CYS',
        'w' => 'CYS',
        'x' => 'CYS',
        'y' => 'CYS',
        'z' => 'CYS',

        'B' => 'ASX',
        'Z' => 'GLX',
        'X' => 'CYS',
    );

    @AA = qw(
      C
      M
      F
      I
      L
      V
      W
      Y
      A
      G
      T
      S
      Q
      N
      E
      D
      H
      R
      K
      P
    );

}

sub runPsipred() {
################# directories #############################
    my ($domainId) = @_;

    open( RD, "$domainId.seq" );
    my $an = 0;    #amino acids number
    my %seq;
    while ( my $line = <RD> ) {
        next if ( $line =~ /^>/ );
        if ( $line =~ /(\S+)/ ) {
            my $sequence = $1;
            my $Lch      = length $sequence;
            for ( my $k = 1 ; $k <= $Lch ; $k++ ) {
                $an++;
                my $seq1 = substr( $sequence, $k - 1, 1 );
                $seq{$an} = $ts{$seq1};
            }
        }
    }
    close(RD);

########### run PSIPRED ####################
`$Pexecdir/psipred $domainId.mtx $Pdatadir/weights.dat $Pdatadir/weights.dat2 $Pdatadir/weights.dat3 $Pdatadir/weights.dat4 > $domainId.ss`;
`$Pexecdir/psipass2 $Pdatadir/weights_p2.dat 1 1.0 1.0 $domainId.ss2 $domainId.ss > $domainId.horiz`;

########### make 'seq.dat' ########################
    open( RD, "$domainId.horiz" );
    open( WR, ">$domainId.dat" );
    my $j = 0;
    my %sec;
    while ( my $line = <RD> ) {
        if ( $line =~ /Conf:\s+(\d+)/ ) {
            my $conf = $1;
            <RD> =~ /Pred:\s+(\S+)/;
            my $pred = $1;
            <RD> =~ /AA:\s+(\S+)/;
            my $aa  = $1;
            my $num = length $aa;
            for ( my $i = 1 ; $i <= $num ; $i++ ) {
                $j++;
                my $conf1 = substr( $conf, $i - 1, 1 );
                my $pred1 = substr( $pred, $i - 1, 1 );
                my $aa1   = substr( $aa,   $i - 1, 1 );
                $sec{$j} = 1;
                $sec{$j} = 2 if ( $conf1 >= 1 && $pred1 eq 'H' );
                $sec{$j} = 4 if ( $conf1 >= 1 && $pred1 eq 'E' );
                printf WR "%5d   %3s%5d%5d\n", $j, $seq{$j}, $sec{$j}, $conf1;
            }
        }
    }
    close(WR);
    close(RD);

############ rmsinp ###################################
    open( WR, ">rmsinp" );
    printf WR "1  $j\n";
    printf WR "$j\n";
    printf WR "$domainId\n";
    close(WR);

    `cp $domainId.ss2 $domainId.psi.ss`;
################# endding procedure ######################
    `sync`;
    sleep(1);

}

sub runPSSpred() {
    my ($domainId) = @_;
################# directories #############################

    my @AA20 = qw(
      A
      R
      N
      D
      C
      Q
      E
      G
      H
      I
      L
      K
      M
      F
      P
      S
      T
      W
      Y
      V
      );    # pssm order

    my @AA21 = qw(
      A
      R
      N
      D
      C
      Q
      E
      G
      H
      I
      L
      K
      M
      F
      P
      S
      T
      W
      Y
      V
      X
      );    # pssm order, 21 AA with "X" added, X=gap

    my %secondary = (
        '1' => 'C',
        '2' => 'H',
        '4' => 'E',
        'C' => '1',
        'H' => '2',
        'E' => '4',
    );

    open( RD, "$domainId.seq" );
    my $an = 0;    #amino acids number
    my %seqQ;
    while ( my $line = <RD> ) {
        next if ( $line =~ /^>/ );
        if ( $line =~ /(\S+)/ ) {
            my $sequence = $1;
            my $Lch      = length $sequence;
            for ( my $k = 1 ; $k <= $Lch ; $k++ ) {
                $an++;
                my $seq1 = substr( $sequence, $k - 1, 1 );
                $seqQ{$an} =$seq1;
            }
        }
    }
    close(RD);
    my $Lch = $an;
########### run PSIPRED ####################

########### check psi-blast #######################
    if (   not -s "$domainId.chk"
        && -s "$domainId.out"
        && -s "$domainId.pssm"
        && -s "$domainId.mtx" )
    {
        print("There is no the blast output file\n");
        exit();
    }

#####
    # Step2: prepare input files for PSSpred
#####
########## generate profile from blast.out ##############################
    # profw,    profile with henikoff weight
    # freqccw,  frequence file with henikoff weight
    # freqccwG, frequence file with nehikoff weight with gap countted
#########################################################################
    my $blosum62 = "
   A  R  N  D  C  Q  E  G  H  I  L  K  M  F  P  S  T  W  Y  V  B  Z  X  *
A  4 -1 -2 -2  0 -1 -1  0 -2 -1 -1 -1 -1 -2 -1  1  0 -3 -2  0 -2 -1 -1 -4 
R -1  5  0 -2 -3  1  0 -2  0 -3 -2  2 -1 -3 -2 -1 -1 -3 -2 -3 -1  0 -1 -4 
N -2  0  6  1 -3  0  0  0  1 -3 -3  0 -2 -3 -2  1  0 -4 -2 -3  3  0 -1 -4 
D -2 -2  1  6 -3  0  2 -1 -1 -3 -4 -1 -3 -3 -1  0 -1 -4 -3 -3  4  1 -1 -4 
C  0 -3 -3 -3  9 -3 -4 -3 -3 -1 -1 -3 -1 -2 -3 -1 -1 -2 -2 -1 -3 -3 -1 -4 
Q -1  1  0  0 -3  5  2 -2  0 -3 -2  1  0 -3 -1  0 -1 -2 -1 -2  0  3 -1 -4 
E -1  0  0  2 -4  2  5 -2  0 -3 -3  1 -2 -3 -1  0 -1 -3 -2 -2  1  4 -1 -4 
G  0 -2  0 -1 -3 -2 -2  6 -2 -4 -4 -2 -3 -3 -2  0 -2 -2 -3 -3 -1 -2 -1 -4 
H -2  0  1 -1 -3  0  0 -2  8 -3 -3 -1 -2 -1 -2 -1 -2 -2  2 -3  0  0 -1 -4 
I -1 -3 -3 -3 -1 -3 -3 -4 -3  4  2 -3  1  0 -3 -2 -1 -3 -1  3 -3 -3 -1 -4 
L -1 -2 -3 -4 -1 -2 -3 -4 -3  2  4 -2  2  0 -3 -2 -1 -2 -1  1 -4 -3 -1 -4 
K -1  2  0 -1 -3  1  1 -2 -1 -3 -2  5 -1 -3 -1  0 -1 -3 -2 -2  0  1 -1 -4 
M -1 -1 -2 -3 -1  0 -2 -3 -2  1  2 -1  5  0 -2 -1 -1 -1 -1  1 -3 -1 -1 -4 
F -2 -3 -3 -3 -2 -3 -3 -3 -1  0  0 -3  0  6 -4 -2 -2  1  3 -1 -3 -3 -1 -4 
P -1 -2 -2 -1 -3 -1 -1 -2 -2 -3 -3 -1 -2 -4  7 -1 -1 -4 -3 -2 -2 -1 -1 -4 
S  1 -1  1  0 -1  0  0  0 -1 -2 -2  0 -1 -2 -1  4  1 -3 -2 -2  0  0 -1 -4 
T  0 -1  0 -1 -1 -1 -1 -2 -2 -1 -1 -1 -1 -2 -1  1  5 -2 -2  0 -1 -1 -1 -4 
W -3 -3 -4 -4 -2 -2 -3 -2 -2 -3 -2 -3 -1  1 -4 -3 -2 11  2 -3 -4 -3 -1 -4 
Y -2 -2 -2 -3 -2 -1 -2 -3  2 -1 -1 -2 -1  3 -3 -2 -2  2  7 -1 -3 -2 -1 -4 
V  0 -3 -3 -3 -1 -2 -2 -3 -3  3  1 -2  1 -1 -2 -2  0 -3 -1  4 -3 -2 -1 -4 
B -2 -1  3  4 -3  0  1 -1  0 -3 -4  0 -3 -3 -2  0 -1 -4 -3 -3  4  1 -1 -4 
Z -1  0  0  1 -3  3  4 -2  0 -3 -3  1 -1 -3 -1  0 -1 -3 -2 -2  1  4 -1 -4 
X -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -4 
* -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4  1 
";
    my %B;
    my @aa;
    my @bb;
    my @lines = split( "\n", $blosum62 );
    foreach my $line (@lines) {

        if ( $line =~
/A  R  N  D  C  Q  E  G  H  I  L  K  M  F  P  S  T  W  Y  V  B  Z  X/
          )
        {
            @aa = split( " ", $line );
        }
        else {
            if ( $line =~ /(\S)\s+(.+)/ ) {
                $a  = $1;
                $b  = $2;
                @bb = split( " ", $b );
                for ( my $i = 1 ; $i <= 23 ; $i++ ) {
                    $B{ $a, $aa[ $i - 1 ] } = $bb[ $i - 1 ];
                }
            }
        }
    }

    my %am;    #amino matrix
    for ( my $cut = 1 ; $cut <= 2 ; $cut++ ) {
        my ( $cut1, $cut2 );    #the condition to choose the homologs.
        if ( $cut == 1 ) {      #without cutoff, for profw
            $cut1 = 1000;
            $cut2 = 1000;
        }
        else {                  #with cutoff, for freqccw, frewccwG
            $cut1 = 0.001;
            $cut2 = 98;
        }

        ######## read blast.out ------------>
        my $ROUND = 0;
        open( BLAST, "$domainId.out" );
        while ( my $line = <BLAST> ) {
            if ( $line =~ /Results from round\s+(\d+)/ ) {
                $ROUND = $1;
            }
        }
        seek( BLAST, 0, 0 );

        my $it = 0;
        while ( my $line = <BLAST> ) {
            if ( $line =~ /Results from round\s+$ROUND/ ) {
                while ( $line = <BLAST> ) {
                    if ( $line =~ /Expect =\s*(\S+),/ ) {
                        my $ev = $1;
                        if ( $ev =~ /e/ ) {
                            $ev = "1$ev";
                        }
                        $ev = sprintf( "%0.9f", $ev );
                        <BLAST> =~ /Identities =\s*\S+\s+\((\S+)\%/;
                        <BLAST>;
                        my $id = $1;
                        if ( $ev < $cut1 && $id < $cut2 ) {
                            $it++;    #number of aligned sequences
                            while ( $line = <BLAST> ) {
                                if (
                                    $line =~ /Quer\S+\s*(\d+)\s+(\S+)\s+(\S+)/ )
                                {
                                    my $i1   = $1;
                                    my $seq1 = $2;
                                    <BLAST>;
                                    <BLAST> =~
                                      /Sbjc\S+\s*(\S+)\s+(\S+)\s+(\S+)/;
                                    my $seq2 = $2;
                                    $seq2 =~ s/\*/X/mg;
                                    $seq2 = uc($seq2);
                                    <BLAST>;
                                    ###
                                    my $L  = length $seq1;
                                    my $m1 = $i1 - 1;
                                    for ( my $i = 1 ; $i <= $L ; $i++ ) {
                                        my $q1 = substr( $seq1, $i - 1, 1 );
                                        my $q2 = substr( $seq2, $i - 1, 1 );
                                        $m1++ if ( $q1 ne '-' );
                                        if ( $q1 ne '-' && $q2 ne '-' ) {
                                            $am{ $it, $m1 } = $q2;
                                        }
                                    }
                                    ###
                                }
                                else {
                                    goto pos1a;
                                }
                            }
                        }
                      pos1a:;
                    }
                }
            }
        }
        close(BLAST);
        ######## include query sequence ---------->
        $it++;
        for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
            $am{ $it, $i } = $seqQ{$i};
        }

    #    goto pos11;
        ###### output MSA for check:
        for ( my $j = 1 ; $j <= $it ; $j++ ) {
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                $am{$j,$i}="" if(not $am{$j,$i});
                my $a = $am{ $j, $i };
                if ( $a !~ /\S/ ) {
                    $a = "-";
                }
                #print "$a";
            }
            #printf "\n";
        }
     # pos11:;

        ####### calculate Henikoff weight $w{i_seq} without gap ----------->
        ##### nA{A,i_pos}: number of times A appear at the position:
        my $w_all = 0;
        my %w;     #Henikoff wight
        my %nA;    #number of time A appear at i
        my %r;     #number of different A at i
        for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
             $a = "";
            for ( my $j = 1 ; $j <= $it ; $j++ ) {
                if ( $am{ $j, $i } and $am{ $j, $i } =~ /\S/ ) {
                    $nA{ $am{ $j, $i }, $i }++;    #number of time A appear at i
                    if ( $a !~ /$am{$j,$i}/ ) {
                        $a .= $am{ $j, $i };
                    }
                }
            }
            $r{$i} = length $a;                    #number of different A at i
        }
        ##### henikoff weight w(i)=sum of 1/rs:
        for ( my $i = 1 ; $i <= $it ; $i++ ) {
            $w{$i} = 0;
            for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
                ####### r: number of different residues in j'th position:
                my $r1 = 0;
                foreach my $A (@AA20) {
                    if ( not $nA{ $A, $j } ) {

                        #   print("nA($A,$j)\n");
                        # $nA{$A,$j}=0
                    }
                    $r1++ if ( $nA{ $A, $j } and $nA{ $A, $j } > 0 );
                }

                if ( $am{ $i, $j } =~ /\S/ )
                { # gap neglected, means lower weight for gapped alignment sequence
                    my $s2 = $nA{ $am{ $i, $j }, $j };
                    my $w1 = 1.0 / ( $r1 * $s2 );    #1/r*s
                    $w{$i} += $w1;
                }
            }
            $w_all += $w{$i};
        }
        #### normalization of w(i):
        for ( my $i = 1 ; $i <= $it ; $i++ ) {
            $w{$i} /= $w_all;                        #normalized to 1
        }

        #^^^^^ Henikoff weight finished ^^^^^^^^^^^^^^^^^

        ########### weighted frequence #################
        my %log1;    #frequence with Helikof weight
        for ( my $i = 1 ; $i <= $it ; $i++ ) {
            for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
                my $A = $am{ $i, $j };
               
                if ( $log1{ $j, $A } ) {
                    $log1{ $j, $A } += $w{$i}; #log1 will be renormalized anyway
                          #$log1{$j,$A}+=1; #log1 will be renormalized anyway
                }
                else {

                    $log1{ $j, $A } = $w{$i};  #log1 will be renormalized anyway
                          #$log1{$j,$A}+=1; #log1 will be renormalized anyway
                }
            }
        }

        #^^^^^^^^^ Henikoff frequence finished ^^^^^^^^^^^^^

        if ( $cut == 1 ) {
            ######### output prof ------------->
            my %S1w;      # profile by direct sum
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                foreach my $A (@AA20) {
                    for ( my $j = 1 ; $j <= $it ; $j++ ) {

                        #$S1{$i,$A}+=$B{$am{$j,$i},$A};
                       if ( $am{ $j, $i } =~ /\S+/) {
                            if ( $S1w{ $i, $A } ) {
                                $S1w{ $i, $A } +=
                                  $B{ $am{ $j, $i }, $A } * $w{$j} * $it;
                            }
                            else {

                                $S1w{ $i, $A } =
                                  $B{ $am{ $j, $i }, $A } * $w{$j} * $it;
                            }
                        }
                    }
                    $S1w{ $i, $A } /= $it;    #equal to $S2
                }
            }
            open( MTX1, ">profw" );
            printf MTX1 "%5d    ", $Lch;
            foreach my $A (@AA20) {
                printf MTX1 "     %s    ", $A;
            }
            printf MTX1 "\n";
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                printf MTX1 "%3d $seqQ{$i} %3d", $i, $i;
                foreach my $A (@AA20) {
                    printf MTX1 " %9.6f", $S1w{ $i, $A };
                }
                printf MTX1 "\n";
            }
            close(MTX1);
        }
        else {
            ######### output freqccw ------------->
            open( FREQ1, ">freqccw" );
            printf FREQ1 "%5d    ", $Lch;
            foreach my $A (@AA20) {
                printf FREQ1 "     %s    ", $A;
            }
            printf FREQ1 "\n";
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                printf FREQ1 "%3d $seqQ{$i} %3d", $i, $i;
                my $norm1 = 0;
                foreach my $A (@AA20) {
                   $log1{$i,$A}=0 if(not $log1{$i,$A});
                         $norm1 += $log1{ $i, $A };
                }
                foreach my $A (@AA20) {
                    printf FREQ1 "%10.7f", $log1{ $i, $A } / $norm1;
                }
                printf FREQ1 "\n";
            }
            close(FREQ1);

            ########################################
            ########## replace gap by "X" --------->
            ########################################
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                for ( my $j = 1 ; $j <= $it ; $j++ ) {
                    if ( $am{ $j, $i } !~ /\S/ ) {
                        $am{ $j, $i } = "X";
                    }
                }
            }

            ####### re-calculate Henikoff weight $w{i_seq} with gap ----------->
            ##### nA{A,i_pos}: number of times A appear at the position:
            $w_all = 0;
            my %w;     #Henikoff wight
            my %nA;    #number of time A appear at i
            my  %r;     #number of different A at i
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                my $a = "";
                for ( my $j = 1 ; $j <= $it ; $j++ ) {
                    if ( $am{ $j, $i } =~ /\S/ ) {
                        $nA{ $am{ $j, $i },
                            $i }++;    #number of time A appear at i
                        if ( $a !~ /$am{$j,$i}/ ) {
                            $a .= $am{ $j, $i };
                        }
                    }
                }
                $r{$i} = length $a;    #number of different A at i
            }
            ##### henikoff weight w(i)=sum of 1/rs:
            for ( my $i = 1 ; $i <= $it ; $i++ ) {
                for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
                    if ( $am{ $i, $j } =~ /\S/ )
                    { # gap neglected, means lower weight for gapped alignment sequence
                        my $s2 = $nA{ $am{ $i, $j }, $j };
                        my $w1 = 1.0 / ( $r{$j} * $s2 );    #1/r*s
                        $w{$i} += $w1;
                    }
                }
                $w_all += $w{$i};
            }
            #### normalization of w(i):
            for ( my $i = 1 ; $i <= $it ; $i++ ) {
                $w{$i} /= $w_all;                           #normalized to 1
            }

            #^^^^^ Henikoff weight finished ^^^^^^^^^^^^^^^^^

            ########### weighted frequence #################
            my %log;     #frequence
            my %log1;    #frequence with Helikof weight
            for ( my $i = 1 ; $i <= $it ; $i++ ) {
                for ( my $j = 1 ; $j <= $Lch ; $j++ ) {
                    my $A = $am{ $i, $j };
                    $log{ $j,  $A } += 1;
                    $log1{ $j, $A } += $w{$i}; #log1 will be renormalized anyway
                }
            }

            #^^^^^^^^^ Henikoff frequence finished ^^^^^^^^^^^^^

            ######### output freqccwG ------------->
            open( FREQ1, ">freqccwG" );
            printf FREQ1 "%5d    ", $Lch;
            foreach my $A (@AA21) {
                printf FREQ1 "     %s    ", $A;
            }
            printf FREQ1 "\n";
            for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
                printf FREQ1 "%3d $seqQ{$i} %3d", $i, $i;
                my $norm1 = 0;
                foreach my $A (@AA21) {
                   $log1{$i,$A}=0 if(not $log1{$i,$A});
                   $norm1 += $log1{ $i, $A };
                }
                foreach my $A (@AA21) {
                    printf FREQ1 "%10.7f", $log1{ $i, $A } / $norm1;
                }
                printf FREQ1 "\n";
            }
            close(FREQ1);
        }
    }

#####
    # Step3: run PSSpred and output results
#####
    my $nprog = 7;
    my %pp;
    for ( my $i = 1 ; $i <= $nprog ; $i++ ) {
        printf "Running PSSpred\n";
        system("$PSSpreddir/PSSpred$i $PSSpreddir/wgt$i output$i.ss");
    }

###### combine different output ------->
    for ( my $i = 1 ; $i <= $nprog ; $i++ ) {
        open( SS, "output$i.ss" );
        my $Lch1 = 0;
        while ( my $line = <SS> ) {
            if ( $line =~ /(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/ ) {
                $Lch1++;
                $pp{ $Lch1, $i, 2 } = $4;    #helix
                $pp{ $Lch1, $i, 4 } = $5;    #extend
                $pp{ $Lch1, $i, 1 } = $6;    #coil
            }
        }
        close(SS);
    }
    my %sec;
    my %rel;
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        my %p;
        for ( my $j = 1 ; $j <= $nprog ; $j++ ) {
            $p{2} += $pp{ $i, $j, 2 };
            $p{4} += $pp{ $i, $j, 4 };
            $p{1} += $pp{ $i, $j, 1 };
        }
        $p{2} /= $nprog;
        $p{4} /= $nprog;
        $p{1} /= $nprog;
        my @p_keys = sort { $p{$b} <=> $p{$a} } keys %p;
        $sec{$i} = $p_keys[0];
        $rel{$i} = int( 0.5 + 10 * ( $p{ $p_keys[0] } - $p{ $p_keys[1] } ) );
        $rel{$i} = 9 if ( $rel{$i} > 9 );
    }

######## SMOOTH ################
    %sec = smooth( $Lch, %sec );

    open( SEQ, ">$domainId.pss" );
    open( SS,  ">$domainId.pss.ss" );
    printf SS "$Lch   coil  helix  beta\n\n";
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        printf SEQ "%5d   %3s%5d%5d\n", $i, $ts{ $seqQ{$i} }, $sec{$i},
          $rel{$i};

        my %p;
        for ( my $j = 1 ; $j <= $nprog ; $j++ ) {
            $p{2} += $pp{ $i, $j, 2 };
            $p{4} += $pp{ $i, $j, 4 };
            $p{1} += $pp{ $i, $j, 1 };
        }
        $p{2} /= $nprog;
        $p{4} /= $nprog;
        $p{1} /= $nprog;
        printf SS "%4d %1s %1s %6.3f %6.3f %6.3f \n",
          $i, $seqQ{$i}, $secondary{ $sec{$i} }, $p{1}, $p{2}, $p{4};
    }
    close(SEQ);
    close(SS);

##### clean files ################
    my @tt = qw(
      psitmp.fasta
      psitmp.pn
      psitmp.sn
      psitmp.mn
      psitmp.aux

      mtx
      pssm
      profw
      freqccw
      freqccwG
    );

    foreach my $t (@tt) {

        #`rm $t`;
    }

    `sync`;
    sleep(1);
}

sub smooth {
    my ( $Lch, %sec ) = @_;
    ####### smooth the predictions ############
    # --2-- => -----
    for ( my $i = 3 ; $i <= $Lch-2 ; $i++ ) {
        if ( $sec{$i} eq "2" ) {
            if ( $sec{ $i - 1 } ne "2" ) {
                if ( $sec{ $i - 2 } ne "2" ) {
                    if ( $sec{ $i + 1 } ne "2" ) {
                        if ( $sec{ $i + 2 } ne "2" ) {
                            $sec{$i} = 1;
                        }
                    }
                }
            }
        }
    }

    # --22-- => ------
    for ( my $i = 1 ; $i <= $Lch-5 ; $i++ ) {
        if ( $sec{ $i + 0 } ne "2" ) {
            if ( $sec{ $i + 1 } ne "2" ) {
                if ( $sec{ $i + 2 } eq "2" ) {
                    if ( $sec{ $i + 3 } eq "2" ) {
                        if ( $sec{ $i + 4 } ne "2" ) {
                            if ( $sec{ $i + 5 } ne "2" ) {
                                $sec{ $i + 2 } = 1;
                                $sec{ $i + 3 } = 1;
                            }
                        }
                    }
                }
            }
        }
    }
    return (%sec);
}

######### combined ###############
sub combine_SS() {
    my ($domainId) = @_;
    my %secondary = (
        '1' => 'C',
        '2' => 'H',
        '4' => 'E',
        'C' => '1',
        'H' => '2',
        'E' => '4',
    );

    my $Lch = 0;
    my ( %seqQ, %score );
    open( RD, "$domainId.psi.ss" );
    while ( my $line = <RD> ) {

        #print "$line";
        if ( $line =~ /(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/ ) {
            $Lch++;
            $seqQ{$Lch} = $2;
            $score{ $Lch, 'psi', 1 } = $4;    #coil
            $score{ $Lch, 'psi', 2 } = $5;    #helix
            $score{ $Lch, 'psi', 4 } = $6;    #beta
        }
    }
    close(RD);

    open( RD, "$domainId.pss.ss" );
    $Lch = 0;
    while ( my $line = <RD> ) {
        if ( $line =~ /(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/ ) {
            $Lch++;
            $seqQ{$Lch} = $2;
            $score{ $Lch, 'pss', 1 } = $4;    #coil
            $score{ $Lch, 'pss', 2 } = $5;    #helix
            $score{ $Lch, 'pss', 4 } = $6;    #beta
        }
    }
    close(RD);
    my ( %sec, %rel );
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        my %p;
        $p{1} = ( $score{ $i, 'psi', 1 } + $score{ $i, 'pss', 1 } ) / 2;
        $p{2} = ( $score{ $i, 'psi', 2 } + $score{ $i, 'pss', 2 } ) / 2;
        $p{4} = ( $score{ $i, 'psi', 4 } + $score{ $i, 'pss', 4 } ) / 2;
        my @p_keys = sort { $p{$b} <=> $p{$a} } keys %p;
        $sec{$i} = $p_keys[0];
        $rel{$i} = int( 0.5 + 10 * ( $p{ $p_keys[0] } - $p{ $p_keys[1] } ) );
        $rel{$i} = 9 if ( $rel{$i} > 9 );

        #printf "$i $sec{$i} $rel{$i}\n";
    }

######## SMOOTH ################
    %sec = smooth( $Lch, %sec );

    open( SEQ, ">$domainId.dat" );
    open( SS,  ">$domainId.dat.ss" );
    printf SS "$Lch   coil  helix  beta\n";
    for ( my $i = 1 ; $i <= $Lch ; $i++ ) {
        printf SEQ "%5d   %3s%5d%5d\n", $i, $ts{ $seqQ{$i} }, $sec{$i},
          $rel{$i};

        my %p;
        $p{1} = ( $score{ $i, 'psi', 1 } + $score{ $i, 'pss', 1 } ) / 2;
        $p{2} = ( $score{ $i, 'psi', 2 } + $score{ $i, 'pss', 2 } ) / 2;
        $p{4} = ( $score{ $i, 'psi', 4 } + $score{ $i, 'pss', 4 } ) / 2;
        printf SS "%4d %1s %1s %6.3f %6.3f %6.3f \n",
          $i, $seqQ{$i}, $secondary{ $sec{$i} }, $p{1}, $p{2}, $p{4};
    }
    close(SEQ);
    close(SS);

}
