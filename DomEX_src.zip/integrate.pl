#!/usr/bin/perl 
#===============================================================================
#
#         FILE: integrate.pl
#
#        USAGE: ./integrate.pl
#
#  DESCRIPTION: i
#
#      OPTIONS: ---
# REQUIREMENTS: ---
#         BUGS: ---
#        NOTES: ---
#       AUTHOR: zhidong xue (zdxue@hust.edu.cn),
# ORGANIZATION:
#      VERSION: 1.0
#      CREATED: 08/20/2014 04:33:46 AM
#     REVISION: ---
#===============================================================================

use strict;
use warnings;

my $DSAM_DIR = "/home/zhidongx/DSAM_WEB";
my $WORK_DIR = "$DSAM_DIR/output";

my $chainId  = $ARGV[0];
my $b_cutoff = $ARGV[1];
my $e_cutoff = $ARGV[2];
my $shift    = $ARGV[3];
my $ppa_file        = "$WORK_DIR/$chainId/$chainId.ppa";
my $blasthit_file   = "$WORK_DIR/$chainId/$chainId.hit";
my $domainpred_file = "$WORK_DIR/$chainId/$chainId.sd";

my %CHKLIST;
my %E;
my %B;
my %TEMPLATE;
my %PARTNER;
my %ENERGY;
my %SEGDOMAIN;
my %BEST_SHIFT;   #key:s40F0F2;value:S40F0F2L-5_R10
my %BEST_B;       # key:S40F0F2;value: b_value
my %TEMPLATETYPE; # key:templateId
open( RD, $ppa_file );
while ( my $line = <RD> ) {
    if($line =~ /(\S+)\s+\d\s+\S+\s+(\S+)\s+\S+\s+\S+/){
    my $domainId = $1;
    my $energy   = $2;
   next  if($shift<1 and not $domainId =~ /L0_R0/);
    $ENERGY{$domainId} = $energy;
    }
    #print("$domainId\t$energy\n");
}
close(RD);

open( RD, $blasthit_file );
while ( my $line = <RD> ) {

    if ( $line =~ /(\S+)\s+(\S+)\s+(\S+)\s+\S+\s+\S+\s+(\S+)\s+\S+/ ) {
        my $templateType = $1;
        my $templateId = $2;
        my $domainId     = $3; #S50F0F2L5_R-10
        my $b            = $4;

       $domainId =~ /(\S+F\dF\d)L(\S{1,3})_R(\S{1,3})/;
       my $queryId=$1;

       next  if($shift<1 and not $domainId =~ /L0_R0/);
       next if ( $b < $b_cutoff - 0.001 );
       next if($ENERGY{$domainId} and $ENERGY{$domainId}>$e_cutoff and  $templateId eq 'Pfam');

        $B{$domainId}            = $b;
        $TEMPLATE{$domainId}     = $templateId;
        $TEMPLATETYPE{$domainId} = $templateType;
        if ( $BEST_B{$queryId} ) {
            if ( $BEST_B{$queryId} < $b - 0.001 ) {
                $BEST_B{$queryId}     = $b;
                $BEST_SHIFT{$queryId} = $domainId;
            }
            elsif ( $BEST_B{$queryId} > $b - 0.001
                and $BEST_B{$queryId} < $b + 0.001 )
            {
                my $old_queryId = $BEST_SHIFT{$queryId};
                if ( $ENERGY{$old_queryId} and $ENERGY{$queryId} and $ENERGY{$old_queryId} > $ENERGY{$queryId} ) {
                    $BEST_B{$queryId}     = $b;
                    $BEST_SHIFT{$queryId} = $domainId;
                }

            }

        }
        else {
            $BEST_B{$queryId}     = $b;
            $BEST_SHIFT{$queryId} = $domainId;
        }
    }
}

# conflict detection of segments.

while ( my ( $key, $value ) = each %BEST_B ) {
   
    my $domainId     = $BEST_SHIFT{$key}; # Key:S50F0F2; $domianId:S50F0F2L5_R5
    my $b            = $value;
    my $templateType = $TEMPLATETYPE{$domainId}; 
    my $templateId   = $TEMPLATE{$domainId};

#    print("$domainId\n");
    my $len     = length($chainId);                 # chainId like "S50"
    my $seg1    = substr( $domainId, $len, 2 );     # S50F0F2 -> F0
    my $seg2    = substr( $domainId, $len + 2, 2 ); # S50F0F2 -> F2

    if ( not $PARTNER{"$chainId-$seg1"} and not $PARTNER{"$chainId-$seg2"} ) {

        $PARTNER{"$chainId-$seg1"}   = "$chainId-$seg2"; #S50-F2
        $SEGDOMAIN{"$chainId-$seg1"} = $domainId;        #S50F0F2
        $PARTNER{"$chainId-$seg2"}   = "$chainId-$seg1"; #S50-F0
        $SEGDOMAIN{"$chainId-$seg2"} = $domainId;        #S50F0F2

    }
    elsif ( $PARTNER{"$chainId-$seg1"} and not $PARTNER{"$chainId-$seg2"} ) {
        my $olddomainId   = $SEGDOMAIN{"$chainId-$seg1"};
        my $oldsegpartner = $PARTNER{"$chainId-$seg1"};
        if (   $B{$olddomainId} < $B{$domainId} - 0.001
            or $B{$olddomainId} > $B{$domainId} - 0.001
            and $B{$olddomainId} < $B{$domainId} + 0.001
            and $ENERGY{$olddomainId} > $ENERGY{$domainId} )
        {
            $PARTNER{"$chainId-$seg1"}   = "$chainId-$seg2";
            $SEGDOMAIN{"$chainId-$seg1"} = $domainId;
            delete( $SEGDOMAIN{$oldsegpartner} );
            delete( $PARTNER{$oldsegpartner} );
            $PARTNER{"$chainId-$seg2"}   = "$chainId-$seg1";
            $SEGDOMAIN{"$chainId-$seg2"} = $domainId;
        }

    }
    elsif ( not $PARTNER{"$chainId-$seg1"} and $PARTNER{"$chainId-$seg2"} ) {

        my $olddomainId   = $SEGDOMAIN{"$chainId-$seg2"};
        my $oldsegpartner = $PARTNER{"$chainId-$seg2"};
        if (   $B{$olddomainId} < $B{$domainId} - 0.001
            or $B{$olddomainId} > $B{$domainId} - 0.001
            and $B{$olddomainId} < $B{$domainId} + 0.001
            and $ENERGY{$olddomainId} > $ENERGY{$domainId} )
        {

            $PARTNER{"$chainId-$seg2"}   = "$chainId-$seg1";
            $SEGDOMAIN{"$chainId-$seg2"} = $domainId;
            delete( $SEGDOMAIN{$oldsegpartner} );
            delete( $PARTNER{$oldsegpartner} );
            $PARTNER{"$chainId-$seg1"}   = "$chainId-$seg2";
            $SEGDOMAIN{"$chainId-$seg1"} = $domainId;

        }

    }
}
close(RD);
open( RD, $domainpred_file );
while ( my $line = <RD> ) {

    $line =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)/;
    my $seqname2       = $1;
    my $seq_length     = $2;
    my $segment_number = $3;
    my $segment_pre    = $4;

    chomp($segment_pre);
    $segment_pre =~ s/\(//g;
    my @segs = split( /\)/, $segment_pre );

    my ( @starts, @ends );
    foreach my $fragment (@segs) {

        $fragment =~ /(\d+)\-(\d+)/;
        push( @starts, $1 );
        push( @ends,   $2 );
    }

    @starts = sort { $a <=> $b } (@starts);
    @ends   = sort { $a <=> $b } (@ends);

    my @FLAG;
    my $sp = "";
    $segment_number = $#starts + 1;
    for ( my $i = 0 ; $i < $segment_number ; $i++ ) {
        $FLAG[$i] = 0;
        #print("$starts[$i]-$ends[$i]\n");
    }
    my @starts_new;
    my @ends_new;

    for ( my $i = 0 ; $i < $segment_number ; $i++ ) {
        $starts_new[$i] = $starts[$i];
        $ends_new[$i]   = $ends[$i];
    }
    my @comp;
    my  $detectInfo='';
    for ( my $i = 0 ; $i < $segment_number ; $i++ ) {
        next if ( $FLAG[$i] );
        if ( $SEGDOMAIN{"$seqname2-F$i"} and $PARTNER{"$seqname2-F$i"} ) {
            my $seg_partner     = $PARTNER{"$seqname2-F$i"};
            my $seg_partner_num = substr( $seg_partner, -1 );
            my $domainId        = $SEGDOMAIN{"$seqname2-F$i"};

               $domainId =~ /(\S+F\dF\d)L(\S{1,3})_R(\S{1,3})/;
            my $queryId=$1;
            my $l_shift = $2;
            my $r_shift = $3;
            $ENERGY{$domainId}=0.0 if(not $ENERGY{$domainId});            
            $detectInfo .= "$domainId\t$TEMPLATE{$domainId}\t$TEMPLATETYPE{$domainId}\t$BEST_B{$queryId}\t$ENERGY{$domainId}\n";          
            #change the boundaries according to the shift assembly
            $ends_new[$i] = $ends[$i] + $l_shift;
            $starts_new[ $i + 1 ] = $starts[$i+1] + $l_shift;
            $starts_new[$seg_partner_num] =
              $starts[$seg_partner_num] + $r_shift;
            $ends_new[ $seg_partner_num - 1 ] =
              $ends[ $seg_partner_num - 1 ] + $r_shift;
            push( @comp, "$i|$seg_partner_num" );
            $FLAG[$i]               = 1;
            $FLAG[$seg_partner_num] = 1;

        }
        else {
            push( @comp, "$i" );
        }
    }
print("$detectInfo");
    chomp($detectInfo);
    `echo "$detectInfo" > "$WORK_DIR/$chainId/$chainId.detect"`;
#print("@comp\n@starts\n@ends\n");
#print("@comp\n@starts_new\n@ends_new\n");
    #check boundary conflict.
    for ( my $i = 0 ; $i < $segment_number - 1 ; $i++ ) {
        if ( $ends_new[$i] != $starts[ $i + 1 ] - 1 ) {
            $starts[ $i + 1 ] = $ends_new[$i] + 1;
        }
    }
    #report the prediction
    for ( my $i = 0 ; $i <= $#comp ; $i++ ) {
        my @temp = split( '\|', $comp[$i] );
        if ( $#temp > 0 ) {
            my $s1 = $temp[0];
            my $s2 = $temp[1];
            $sp .=
"($starts_new[$s1]-$ends_new[$s1]|$starts_new[$s2]-$ends_new[$s2])";
        }

        if ( $#temp == 0 ) {
            my $s1 = $temp[0];
            $sp .= "($starts_new[$s1]-$ends_new[$s1])";
        }

    }
    my @ttt = split( '\)\(', $sp );
    my $newdomainnum = $#ttt + 1;
    my $final="$seqname2\t$seq_length\t$newdomainnum\t$sp";
    print("$seqname2\t$seq_length\t$newdomainnum\t$sp\n");
    if($shift>0){
    `echo "$final" > "$WORK_DIR/$chainId/$chainId.final"`;
   }else{
    `echo "$final" > "$WORK_DIR/$chainId/$chainId.result"`;
   }
}
