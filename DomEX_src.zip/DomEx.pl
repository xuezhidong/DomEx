#!/usr/bin/env perl 
#===============================================================================
#
#         FILE: DomEx.pl
#
#        USAGE: ./DomEx.pl -seqname  S50  -shift 1
#
#  DESCRIPTION: This program is developed for discontinuous domain prediction using segments
#               assembly.
#
# REQUIREMENTS: put the data  input $DomEx_DIR/output. Users can check output directory for examples.
#       AUTHOR: Dr. Zhidong XUE , zdxue@isyslab.org; 
# ORGANIZATION:
#      VERSION: 1.0
#      CREATED: 12/09/13 15:58:33
#     REVISION: ---
#===============================================================================

use strict;
use warnings;
use Getopt::Long;
####################################################################
my $DomEx_DIR   = "/home/zhidongx/DomEx_WEB";

my $NR_DIR     = "$DomEx_DIR/nr";
my $DomEx_NR_DIR = "$DomEx_DIR/lib";
my $BLAST_BIN  = "$DomEx_DIR/blast/bin/";
#my $BLAST_BIN  = "/opt/bio/ncbi/bin/";
my $workdir = "$DomEx_DIR/output";
my $b_value = 0.3;
my $T_ppa   =-1.90;
#############################################################

my $operating_system = $^O;
unless ( $operating_system eq "linux" ) {
    printf(
        "Your operating system $operating_system is unsupported at this time\n"
    );
    printf("Currently only Linux is supported\n");

    exit();
}

my ( $seqname, @shiftRange );
GetOptions(
    'seqname:s' => \$seqname,
    'workdir:s' => \$workdir,
    'b:s'       => \$b_value
);



if ( !$seqname ) {
    printf "SAM USAGE:\n";
    printf "Mandatory arguments:\n";
    printf "./sam_all.pl -seqname $seqname\n";
    printf
"Optional arguments whose default values have been set in the config.ini of this package.\n";
    printf "      -workdir workdir: the work directory.Defaut:'./workspace'\n";
    printf
"      -shift   shiftflag:set the assembling strategy.1:Yes,assemble the seqments using shift boundary strategy; 0:no. Default:0\n";
    printf
"      -b b_value: the cutoff of the parameter b(0.1<=b<=0.9). Default:0.1.\n";
    exit();
}

if ( not -e "$workdir" ) {
    print "[main] workdir:'$workdir' doesn't exist.";
    exit();
}
if (   not -e "$workdir/$seqname/$seqname.fasta"
    or not -e "$workdir/$seqname/$seqname.sd" )
{
    print
"[main] There is no $seqname.fasta or $seqname.sd in the directory:$workdir/$seqname!\n"
      . "[main] The $seqname.fasta and $seqname.sd  should be putted into the directory:$workdir/$seqname!\n";
    exit();
}


if ( not -e "$workdir/$seqname/check.txt" ) {
    `echo "notrunning 10" > $workdir/$seqname/check.txt`;

}
my $check = `cat "$workdir/$seqname/check.txt"`;
$check =~ /(\S+)\s+(\d+).*/;
my $running  = $1;
my $runcount = $2;
  $runcount++;
#`echo 'blastrunning 1000' > '$workdir/$seqname/check.txt'`;
if ( $running eq 'notrunning' ) {
     my $isshift=0;
    &assemble( $seqname, $workdir, $isShift );
    &runBlast_cluster( $workdir, $seqname );
}
if ( $running eq 'blastrunning' ) {
    if ( &checkOK( $workdir, $seqname ) == 1 or $runcount > 100 ) {

        my $result = &findBlastHits( $seqname, $workdir, $b_value );
        `echo '$result' > '$workdir/$seqname/$seqname.hit'`;
        `echo 'blasthit_finished 0' > '$workdir/$seqname/check.txt' `;
    }
    else {
        `echo 'blastrunning $runcount'>'$workdir/$seqname/check.txt'`;
    }

}


$running=&checkstatus();
if ( $running eq 'blasthit_finished' ) {
    &runPPA_cluster( $seqname, $workdir );
    `echo 'PPArunning $runcount'>'$workdir/$seqname/check.txt'`;
}

$running=&checkstatus();
if ( $running eq 'PPArunning' ) {
    my $result2 = &collectPPAResult( $seqname, $workdir );
    if ( not $result2 =~ /notok/ ) {
        chomp($result2);
        `echo '$result2' > '$workdir/$seqname/$seqname.ppa'`;
        `echo 'PPA_finished $runcount'>'$workdir/$seqname/check.txt'`;
    }else{
      
        `echo 'PPArunning $runcount'>'$workdir/$seqname/check.txt'`;
    }
}

$running=&checkstatus();
if($running =~ /PPA_finished/){
  `perl "$DomEx_DIR/integrate.pl" $seqname $b_value $T_ppa 0`;
  `perl "$DomEx_DIR/integrate.pl" $seqname $b_value $T_ppa 1`;
  `echo 'DomEx_finished $runcount'>'$workdir/$seqname/check.txt'`;

}

sub checkstatus() {
    my $check = `cat "$workdir/$seqname/check.txt"`;
    $check =~ /(\S+)\s+(\d+).*/;
    my $running  = $1;
    my $runcount = $2;
    return $running;

}

sub collectPPAResult {
    my ( $seqname, $workdir ) = @_;
    my @hits   = `cat '$workdir/$seqname/$seqname.hit'`;
    my $output = '';
    for ( my $i = 0 ; $i <= $#hits ; $i++ ) {
          if(  $hits[$i] =~
              /(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/){
            my $templateType = $1;
            my $templateId   = $2;
            my $queryShiftId = $3;
            if ( -e "$workdir/$seqname/$queryShiftId/$queryShiftId.rst" ) {
                my @temp =
                  `cat '$workdir/$seqname/$queryShiftId/$queryShiftId.rst'`;
                $output .= "$queryShiftId\t$temp[0]";
            }else{
               $output="notok";
               last;
            }        
        }
    }
    return $output;
}

sub runPPA {
    my ( $seqname, $workdir ) = @_;
    my @hits = `cat '$workdir/$seqname/$seqname.hit'`;
        for ( my $i = 0 ; $i <= $#hits ; $i++ ) {
          
            next if (  $hits[$i] =~ /nodcd/ );
            $hits[$i] =~
              /(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/;
            my $templateType = $1;
            my $templateId   = $2;
            my $queryShiftId = $3;
 print("$seqname $templateId $queryShiftId\n");
 
`perl $DomEx_DIR/PPA/PPAcheckdcd.pl $seqname $templateId $queryShiftId`;

        }
 }

sub runPPA_cluster {
    my ( $seqname, $workdir ) = @_;
    my @hits = `cat '$workdir/$seqname/$seqname.hit'`;
        for ( my $i = 0 ; $i <= $#hits ; $i++ ) {
          
            next if (  $hits[$i] =~ /nodcd/ );
            $hits[$i] =~
              /(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/;
            my $templateType = $1;
            my $templateId   = $2;
            my $queryShiftId = $3;
# print("$seqname $templateId $queryShiftId\n");
 
`echo "perl $DomEx_DIR/PPA/PPAcheckdcd.pl $seqname $templateId $queryShiftId" > "$workdir/$seqname/record/$queryShiftId.sh"`;
`chmod +x "$workdir/$seqname/record/$queryShiftId.sh"`;
`qsub "$workdir/$seqname/record/$queryShiftId.sh" -e "$workdir/$seqname/record" -o "$workdir/$seqname/record" -l "nodes=1,walltime=12:00:00"`;

        }
 }



sub assemble() {
    my ( $seqname, $workdir, $isShift ) = @_;

    my @shiftRange;
    if ( $isShift == 1 ) {
        @shiftRange = ( 0, -5, 5, -10, 10 );
    }
    else {
        @shiftRange = (0);
    }

    my $segdef = `cat "$workdir/$seqname/$seqname.sd"`;
    chomp($segdef);
    $segdef =~ /(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/;
    my $chainId      = $1;
    my $length       = $2;
    my $numSegments  = $3;
    my $segments_def = $4;
    if($numSegments<3){
      print("Segement number is less than 3.\nDomEx can't assemble the putative domains");
      exit(0); 
      
     } 
   
    my $seq = `cat $workdir/$seqname/$seqname.fasta`;    # no >xxx line, here.
    $seq =~ s/\s//g;
    my @segments;
    chop($segments_def);
    $segments_def =~ s/\(//g;
    @segments = split( /\)/, $segments_def );
    my ( @starts, @ends );
    foreach my $fragment (@segments) {

        $fragment =~ /(\d+)\-(\d+)/;
        push( @starts, $1 );
        push( @ends,   $2 );
    }

    @starts = sort { $a <=> $b } (@starts);
    @ends   = sort { $a <=> $b } (@ends);

    open( WRLIST, ">$workdir/$seqname/$seqname.list" );
    for ( my $i = 0 ; $i < $#segments ; $i++ ) {
        my $start = $starts[$i];
        my $end   = $ends[$i];
        for ( my $j = $i + 2 ; $j <= $#segments ; $j++ ) {
            my $start2 = $starts[$j];
            my $end2   = $ends[$j];
            for ( my $n = 0 ; $n <= $#shiftRange ; $n++ ) {
                my $start_seg1 = $start;
                my $end_seg1   = $end + $shiftRange[$n];
                my $subseq =
                  substr( $seq, $start - 1,
                    $end + $shiftRange[$n] - $start + 1 );
                for ( my $m = 0 ; $m <= $#shiftRange ; $m++ ) {
                    my $start_seg2 = $start2 + $shiftRange[$m];
                    my $end_seg2   = $end2;
                    my $subseq2    = substr(
                        $seq,
                        $start2 + $shiftRange[$m] - 1,
                        $end2 - $start2 + 1
                    );
                    my $chainId = "$chainId" . "F$i" . "F$j"
                      . "L$shiftRange[$n]_R$shiftRange[$m]";
                    my $cut = length($subseq);
                    my $len = $cut + length($subseq2);

                    `mkdir -p "$workdir/$seqname/$chainId"`;
                    open( WR, ">$workdir/$seqname/$chainId/$chainId.fasta" );
                    printf WR ">$chainId\n";
                    printf WR "$subseq$subseq2\n";
                    close(WR);

                    my $rec =
"$chainId\t$len\t$cut\t($start_seg1\-$end_seg1)($start_seg2\-$end_seg2)\t$i\t$j";
                    open( WRREC, ">$workdir/$seqname/$chainId/$chainId.rec" );
                    printf WRREC "$rec\n";
                    close(WRREC);
                    printf WRLIST "$rec\n";
                }
            }
        }
    }

    `echo 'notrunning 0' >$workdir/$seqname/check.txt`;
    close(WRLIST);
}    # end of asseble()

sub findBlastHits() {
    my ( $seqname, $workdir, $b_value ) = @_;
    my $result = "";
    open( RDLIST, "<$workdir/$seqname/$seqname.list" );
    while ( my $line = <RDLIST> ) {
        chomp($line);
        $line =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)/;
        my $chainId = $1;
        my $length  = $2;
        my $cut     = $3;
        my $sd      = $4;
        my $num1    = $5;
        my $num2    = $6;

        if ( not -e "$workdir/$seqname/$chainId/$chainId.out" ) {
            &runblast( $workdir, $seqname, $chainId );
        }

        my $result2 = &dcdcheck( $workdir, $seqname, $chainId, $b_value );
        $result .= $result2;
    }
    chomp($result);
    return $result;
}

sub integrate() {

    my ( $seqname, $workdir, $b_value ) = @_;
    my %map_segments;
    my $dcd_domain_num = 0;
    my $dcd            = '';
    my $result         = '';

    my $sp = `cat $workdir/$seqname/$seqname.sd`;
    chomp($sp);

    $sp =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)/;
    my $seqname2       = $1;
    my $seq_length     = $2;
    my $segment_number = $3;
    my $segment_define = $4;

    $result = "\nThe sequence name:$seqname\nWork directory:$workdir\n";
    $result .=
"Sequence length:$seq_length\nSegment Number:$segment_number\nSegments:$segment_define\n";
    $result .= "\nSegments Assembling:\n";
    $result .=
      "ID\tLength\tPositionon\tSegments\tNum.of 1st Seg.\tNum of 2nd Seg.\n";

    my $temp = `cat "$workdir/$seqname/$seqname.list"`;
    $result .= "$temp\n";
    $result .= "Discontinuous Domain Detection:\n";

    chomp($segment_define);
    $segment_define =~ s/\(//g;
    my @segs = split( /\)/, $segment_define );

    my ( @starts, @ends );
    foreach my $fragment (@segs) {

        $fragment =~ /(\d+)\-(\d+)/;
        push( @starts, $1 );
        push( @ends,   $2 );
    }

    @starts = sort { $a <=> $b } (@starts);
    @ends   = sort { $a <=> $b } (@ends);

    for ( my $i = 0 ; $i < $segment_number ; $i++ ) {
        $map_segments{$i} = 0;
    }

    my $NUM = 0;
    open( RDLIST, "<$workdir/$seqname/$seqname.list" );
    while ( my $line = <RDLIST> ) {
        chomp($line);
        $line =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)/;
        my $chainId = $1;
        my $length  = $2;
        my $cut     = $3;
        my $sd      = $4;
        my $num1    = $5;
        my $num2    = $6;
        print "$num1:$num2\n";
        $NUM++;
        $result .= "\nNO.$NUM :$chainId.\n";

        if ( $map_segments{$num1} > 0 or $map_segments{$num2} > 0 ) {
            $result .=
"\t One of the segments has been detected into the other domains\n";
            next;
        }

        if ( not -e "$workdir/$seqname/$chainId/$chainId.out" ) {
            &runblast( $workdir, $seqname, $chainId );
        }

        my $result2 = &dcdcheck( $workdir, $seqname, $chainId, $b_value );
        if ( not $result2 eq 'nodcd' ) {
            $result2 =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+).*/;
            my $templateId   = $2;
            my $templateType = $1;
            my $rec          = $3;
            my $tsscore      = $4;
            my $si           = $5;
            my $max_b        = $6;

            #            if ( not $rec eq $chainId ) {
            #                next;
            #            }
            #            else {
            $dcd_domain_num++;
            $map_segments{$num1} = $dcd_domain_num;
            $map_segments{$num2} = $dcd_domain_num;

            $sd =~ /\((\d+)\-(\d+)\)\((\d+)\-(\d+)\)/;
            $dcd = "$dcd" . "($1-$2|$3-$4)";
            $result .=
              "\tDomain Template:$templateId\n\tTemplate Type:$templateType\n";
            $result .=
              "\tTs-score:$tsscore\n\tSI-score:$si\n\tMaxmum b:$max_b\n";

            #            }
        }
        else {
            $result .= "\tNot a Discontinuous Domain Detection.\n";
        }
    }
    close(RDLIST);
    while ( my ( $key, $value ) = each %map_segments ) {
        if ( not $value > 0 ) {
            my $domain = "($starts[$key]\-$ends[$key])";
            $dcd = $domain . $dcd;
        }
    }
    $result .= "\nThe final detection result:\n\t$dcd\n";
    open( WRRESULT, ">$workdir/$seqname/$seqname.result" );
    printf WRRESULT "$result\n";
    close(WRRESULT);
    print "$result\n";

}    #end of function

#===  FUNCTION  ================================================================
#         NAME: runblast
#      PURPOSE:
#   PARAMETERS:
#      RETURNS: void
#  DESCRIPTION: run psiblast alignment. It'll take more time if using shift strategy assembling.
#       THROWS: no exceptions
#     COMMENTS: none
#     SEE ALSO: n/a
#===============================================================================
sub runblast() {
    my ( $workdir, $seqname, $chainId ) = @_;
    my $targetdir = "$workdir/$seqname/$chainId";

    if ( not -e "$targetdir/$chainId.fasta" ) {
        print "[runblast] $targetdir/$chainId.fasta doesn't exist!\n";
        exit();
    }
    if ( not -e "$workdir/$seqname/$chainId/$chainId.chk" ) {
`$BLAST_BIN/blastpgp -i "$targetdir/$chainId.fasta" -b 0 -o "$targetdir/$chainId.out1" -j 3 -C "$targetdir/$chainId.chk" -e 0.001 -d $NR_DIR/nr`;
    }

    if ( -e "$targetdir/$chainId.chk"
        and not -e "$targetdir/$chainId.out" )
    {

`$BLAST_BIN/blastpgp -i "$targetdir/$chainId.fasta" -R "$targetdir/$chainId.chk" -o "$targetdir/$chainId.out" -e 0.001 -d "$DomEx_NR_DIR/pfam_scop_cath90"`;

    }

}    #runblast

sub runBlast_cluster() {
    my ( $workdir, $seqname ) = @_;
    my @LINES;
    `mkdir -p $workdir/$seqname/record`;
    `rm -f $workdir/$seqname/record/*`;
    open( RD, "<$workdir/$seqname/$seqname.list" );
    while ( my $line = <RD> ) {
        chomp($line);
        push( @LINES, $line );

    }
    close(RD);

    my $taskperjob = 1;
    my $jobnum     = int( $#LINES / $taskperjob + 1 );
    for ( my $i = 0 ; $i < $jobnum ; $i++ ) {
        my $jobname = "DomEx_$seqname" . "_$i";
        open( WR, ">$workdir/$seqname/record/$jobname.list" );
        for ( my $j = 0 ; $j < $taskperjob ; $j++ ) {
            my $index = $i * $taskperjob + $j;
            if ( $index > $#LINES ) {
                last;
            }
            printf WR "$LINES[$index]\n";

        }
        close(WR);
        my $job = `cat "$DomEx_DIR/bin/runblast.pl"`;
        $job =~ s/#JOBID#/$jobname/;
        $job =~ s/#SEQNAME#/$seqname/;
        open( WR, ">$workdir/$seqname/record/$jobname.pl" );
        printf WR "$job";
        close(WR);
        `chmod +x $workdir/$seqname/record/$jobname.pl`;
`qsub $workdir/$seqname/record/$jobname.pl -e "$workdir/$seqname/record" -o "$workdir/$seqname/record" -l "nodes=1:ppn=1,walltime=12:00:00"`;

    }
    `echo "blastrunning  0" >$workdir/$seqname/check.txt`;

}

#===  FUNCTION  ================================================================
#         NAME: dcdcheck
#      PURPOSE:
#   PARAMETERS: workdir,seqname,assembled chainId, cutoff of b
#      RETURNS: A string like  "$templateId\t$templateType\t$chainId\t$tsscore\t$si\t$Max_b".
#               Max_b is larger than cutoff of b.
#       THROWS: no exceptions
#     COMMENTS: none
#     SEE ALSO: n/a
#===============================================================================
sub dcdcheck() {
    my ( $workdir, $seqname, $chainId, $b0 ) = @_;
    my $chainId_dir  = "$workdir/$seqname/$chainId";
    my $minIdentity0 = 0.2;
    my $minCov0      = 0.75;
    my $expect0      = 10;
    my $templateType;
    my %PfamPdbMap;
    my $output = "nodcd\n";
    my %record;

    if ( not -e "$chainId_dir/$chainId.rec" ) {
        print "[dcdcheck]:$chainId.rec doesn't exist.";
        exit();
    }

    my $rec = `cat $chainId_dir/$chainId.rec`;
    $rec =~ /(\S+)\t(\d+)\t(\d+).*/;
    my $chainId1    = $1;
    my $chainLength = $2;
    my $chainCut    = $3;
    if ( not -e "$chainId_dir/$chainId.out" ) {
        print "dcdcheck:$chainId_dir/$chainId.out doesn't exist.\n";
        exit();
    }
    open( RD, "<$chainId_dir/$chainId.out" );
    my @array;
    while ( my $line = <RD> ) {
        push( @array, $line );
    }
    close(RD);
    my $maxa = 0;
    for ( my $b = 0.9 ; $b >= $b0 ; $b -= 0.1 ) {
        my $templateId;
        for ( my $i = 0 ; $i < $#array ; $i++ ) {
            my $line = $array[$i];
            if ( $line =~ /No hits found/ ) {
                last;
            }

            if ( $line =~ /^>(\S+)/ ) {
                $templateId = $1;
                my $next = 0;
                for ( my $j = $i + 1 ; $j < $i + 100 ; $j++ ) {
                    my $ln = $array[$j];
                    if ( $ln =~ /^>.*/ or $ln =~ /Database:/ ) {
                        $next = $j;
                        last;
                    }
                }

                my $tmpstr = substr( $chainId, 0, 5 );
                $tmpstr =~ tr/[A-Z]/[a-z]/;
                my @temp = split( '\/', $templateId );
                $templateId = $temp[0];
                if ( $templateId =~ /$tmpstr/ ) {
                    $i = $next - 1;
                    next;
                }

                #move out the same chain as the sample from pfam;
                my $templateLength = 0;
                for ( $i = $i + 1 ; ; $i++ ) {
                    my $temp = $array[$i];
                    if ( $temp =~ /Length = (\S+)/ ) {
                        $templateLength = $1;
                        last;
                    }
                }
                $array[ $i + 2 ] =~ /Expect = (\S+),/;

                my $expect = $1;
                $expect = "2$expect" if ( $expect =~ /^e\-(\d+)/ );

                $array[ $i + 3 ] =~ /Identities =\s+(\d+)\/(\d+)\s+\((\d+)\S+/;
                my $aligned    = $1;
                my $len        = $2;
                my $percentage = $3;

                $array[ $i + 5 ] =~ /Query:\s+(\d+)/;
                my $start = $1;
                my $end   = 0;
                my $align = "";
                for ( my $n = $i + 5 ; $n <= $next - 4 ; $n += 4 ) {
                    my $query = $array[$n];
                    last if ( length($query) < 10 );
                    $query =~ /Query:\s+\d+\s+\S+\s+(\d+)/;
                    $end = $1;
                    my $tmp = $array[ $n + 1 ];
                    chop($tmp);
                    $align .= substr( $tmp, 11 );

                }

                if ( abs( $chainLength - $templateLength ) / $chainLength < 0.25
                    and $percentage > 0.2 )
                {

                    my $coverage = ( $end - $start ) / $chainLength;
                    if ( $chainCut < $end - 20 and $chainCut > $start + 20 ) {
                        my $L1        = $chainCut - $start;
                        my $L2        = $end - $chainCut;
                        my $coverage1 = $L1 / ($chainCut);
                        my $coverage2 = $L2 / ( $chainLength - $chainCut );
                        my $minCov =
                          $coverage1 < $coverage2 ? $coverage1 : $coverage2;
                        my $diffCov = abs( $coverage1 - $coverage2 );

                        my $align1 = substr( $align, 0, $chainCut - $start );
                        my $align2 = substr( $align, $chainCut - $start );

                        $align1 =~ s/\s//g;
                        $align2 =~ s/\s//g;
                        my $sim1 =
                          length($align1) /
                          $L1;    #total aligned number excluding gap
                        my $sim2        = length($align2) / $L2;           #
                        my $minIdentity = $sim1 < $sim2 ? $sim1 : $sim2;
                        my $diffSim     = abs( $sim1 - $sim2 );
                        my $identity    = $aligned / $templateLength;
                        my $tsscore =
                          &cal_tsscore( $identity, $coverage, $expect,
                            $expect0 );

                        my $y = &cal_y( $tsscore, $b );
                        my $si =
                          sqrt( $diffCov * $diffCov + $diffSim * $diffSim );

                        if (    $minCov > $minCov0
                            and $minIdentity > $minIdentity0
                            and $tsscore > 0.1 )
                        {

                            my $frac = $tsscore / ( $si + 0.05 );
                            if ( $si < $y and $si < 0.3 and $tsscore > 0.1 ) {
                                if ( $frac > $maxa ) {
                                    if ( $templateId =~ /^d/ ) {
                                        $templateType = "SCOP";
                                    }
                                    elsif ( $templateId =~ /^[A-Z]/ ) {
                                        $templateType = "Pfam";
                                        my $tmpPfamId =
                                          substr( $templateId, 0, 6 );
                                        if ( $PfamPdbMap{$tmpPfamId} ) {
                                            $templateType =
                                              "Pfam_known_structure";
                                        }
                                    }
                                    else {
                                        $templateType = "CATH";
                                    }
                                    $record{$chainId} = sprintf(
"%s\t%s\t%s\t%0.3f\t%0.3f\t%0.1f\t%0.3f\n",
                                        $templateType, $templateId, $chainId,
                                        $tsscore, $si, $b, $identity );

                                    #print "$record{$chainId}\n";
                                    $maxa   = $frac;
                                    $output = $record{$chainId};

                     #"$templateId\t$templateType\t$chainId\t$tsscore\t$si\t$x";
                                }    #end frac/maxa
                            }    #end if si y
                        }    #endif mincov

                    }    #end chaincut
                }    #endif abs
            }    #endif line
        }    #endfor array

    }    #endfor  b

    #    `echo $output > $chainId_dir/$chainId.r`;
    return $output;
}    #end dcdchecker

sub cal_y() {
    my ( $tsscore, $b ) = @_;
    my $y = 2 * $tsscore - $b;
    $y = 0.1 if ( $y < 0.1 and $y >= 0.0 );
    $y = 0.3 if ( $y > 0.3 );
    $y = 0.0 if ( $y < 0 );
    return $y;
}    #end of cal_y

sub cal_weight_coverage {
    my ($cov) = @_;
    my $value = 0;
    my $a     = 3 * $cov - 1;
    if ( $a > 1 ) {
        $value = 1 / ( 1 + ( 1 / $a )**5 );
    }
    return $value;
}

sub cal_tsscore {
    my ( $identity, $cov, $expect, $E0 ) = @_;
    $expect = 9e-99 if ( $expect == 0 );
    my $a = -log($expect) / log(10);
    my $weight_evalue = $E0 < $a ? $E0 : $a;
    $weight_evalue /= $E0;
    my $weight_cov = &cal_weight_coverage($cov);
    my $tsscore    = $weight_evalue * $weight_cov * $identity;
    return $tsscore;
}

sub call_pfam_pdb_map {
    open( RD, "<$DomEx_DIR/lib/pfam_pdb_map" );
    my %map;
    while ( my $line = <RD> ) {
        my @cols    = split( ';', $line );
        my $pfamId  = $cols[5];
        my $pdbId   = $cols[0];
        my $chainId = $pdbId . $cols[1];

        my $ref = $map{$pfamId};
        if ( not $ref ) {
            my @array;
            push( @array, $chainId );
            $map{$pfamId} = \@array;
        }
        else {
            push( @$ref, $chainId );
        }

    }
    close(RD);
    return %map;
}

sub check_pfam_pdb_map {
    my ( $map, $pfamId, $chainId ) = @_;
    my $bl  = 0;
    my $ref = $$map{$pfamId};

    $chainId =~ tr/[A-Z]/[a-z]/;
    $pfamId  =~ tr/[A-Z]/[a-z]/;
    foreach my $ci (@$ref) {
        if ( $ci eq $chainId ) {
            $bl = 1;
            last;
        }
    }
    return $bl;

}

sub checkOK() {
    my ( $workdir, $seqname ) = @_;
    my $flag = 1;
    open( RDLIST, "<$workdir/$seqname/$seqname.list" );
    while ( my $line = <RDLIST> ) {
        chomp($line);
        $line =~ /(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)\t(\S+)/;
        my $chainId = $1;
        my $length  = $2;
        my $cut     = $3;
        my $sd      = $4;
        my $num1    = $5;
        my $num2    = $6;

        if ( not -e "$workdir/$seqname/$chainId/$chainId.out" ) {
            $flag = 0;
            last;
        }
    }
    if ( $flag == 1 ) {
        `echo "blastok 99999999" > $workdir/$seqname/check.txt`;
    }
    return $flag;
}
